@extends('reeds.admin.layout.adminlayout')

@section('content')
<div class="max-w-4xl mx-auto">
    <!-- Header -->
    <div class="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
            <h1 class="text-3xl font-bold text-text-black">Import Employees</h1>
            <p class="text-gray-600 mt-2">Upload Excel/CSV file to import employee data</p>
        </div>
        <div class="flex space-x-3 mt-4 md:mt-0">
            <a href="{{ route('admin.employees.export') }}" class="bg-secondary-blue text-white px-6 py-3 rounded-lg font-semibold hover:bg-[#1e7a9e] transition duration-300 shadow-md flex items-center space-x-2">
                <i class="fas fa-download"></i>
                <span>Export Employees</span>
            </a>
            <a href="{{ route('admin.employees.index') }}" class="bg-gray-500 text-white px-6 py-3 rounded-lg font-semibold hover:bg-gray-600 transition duration-300 shadow-md flex items-center space-x-2">
                <i class="fas fa-arrow-left"></i>
                <span>Back to Employees</span>
            </a>
        </div>
    </div>

    <!-- Import Card -->
    <div class="bg-white rounded-xl shadow-md border border-gray-100 p-6">
        <div class="mb-6">
            <h2 class="text-xl font-bold text-text-black mb-2">Upload Employee Data</h2>
            <p class="text-gray-600">Upload an Excel or CSV file containing employee information.</p>
        </div>

        <!-- File Upload Area -->
        <div id="uploadArea" class="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-secondary-blue transition duration-150 mb-6">
            <div class="max-w-md mx-auto">
                <i class="fas fa-file-excel text-4xl text-green-500 mb-4"></i>
                <h3 class="text-lg font-semibold text-text-black mb-2">Drop your file here</h3>
                <p class="text-gray-500 text-sm mb-4">or click to browse</p>
                <input type="file" id="fileInput" class="hidden" accept=".xlsx,.xls,.csv">
                <button onclick="document.getElementById('fileInput').click()" class="bg-primary-red text-white px-6 py-2 rounded-lg font-semibold hover:bg-[#c22120] transition duration-300">
                    Choose File
                </button>
                <p class="text-xs text-gray-400 mt-3">Supported formats: XLSX, XLS, CSV (Max: 10MB)</p>
            </div>
        </div>

        <!-- Selected File Info -->
        <div id="fileInfo" class="hidden mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-3">
                    <i class="fas fa-file-excel text-blue-500 text-xl"></i>
                    <div>
                        <p class="font-medium text-text-black" id="fileName"></p>
                        <p class="text-sm text-gray-500" id="fileSize"></p>
                    </div>
                </div>
                <button onclick="removeFile()" class="text-red-500 hover:text-red-700">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </div>

        <!-- Import Button -->
        <div class="flex justify-end">
            <button id="importBtn" onclick="processImport()" class="bg-primary-red text-white px-8 py-3 rounded-lg font-semibold hover:bg-[#c22120] transition duration-300 shadow-md flex items-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed" disabled>
                <i class="fas fa-upload"></i>
                <span>Import Employees</span>
            </button>
        </div>
    </div>

    <!-- Template Download Card -->
    <div class="bg-white rounded-xl shadow-md border border-gray-100 p-6 mt-6">
        <div class="flex items-center justify-between">
            <div>
                <h3 class="text-lg font-semibold text-text-black mb-2">Download Template</h3>
                <p class="text-gray-600 text-sm">Use our template to ensure proper formatting</p>
            </div>
            <a href="#" onclick="downloadTemplate()" class="bg-green-500 text-white px-6 py-2 rounded-lg font-semibold hover:bg-green-600 transition duration-300 flex items-center space-x-2">
                <i class="fas fa-download"></i>
                <span>Download Template</span>
            </a>
        </div>
    </div>

    <!-- Instructions -->
    <div class="bg-white rounded-xl shadow-md border border-gray-100 p-6 mt-6">
        <h3 class="text-lg font-semibold text-text-black mb-4">Import Instructions</h3>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div class="space-y-3">
                <div class="flex items-start space-x-3">
                    <div class="w-6 h-6 bg-primary-red rounded-full flex items-center justify-center mt-1">
                        <span class="text-white text-xs font-bold">1</span>
                    </div>
                    <div>
                        <p class="font-medium text-text-black">Required Fields</p>
                        <p class="text-sm text-gray-600">Employee Code, First Name, Last Name, Department</p>
                    </div>
                </div>
                <div class="flex items-start space-x-3">
                    <div class="w-6 h-6 bg-primary-red rounded-full flex items-center justify-center mt-1">
                        <span class="text-white text-xs font-bold">2</span>
                    </div>
                    <div>
                        <p class="font-medium text-text-black">File Format</p>
                        <p class="text-sm text-gray-600">Use Excel (.xlsx, .xls) or CSV format</p>
                    </div>
                </div>
            </div>
            <div class="space-y-3">
                <div class="flex items-start space-x-3">
                    <div class="w-6 h-6 bg-primary-red rounded-full flex items-center justify-center mt-1">
                        <span class="text-white text-xs font-bold">3</span>
                    </div>
                    <div>
                        <p class="font-medium text-text-black">Column Headers</p>
                        <p class="text-sm text-gray-600">Keep the first row as headers</p>
                    </div>
                </div>
                <div class="flex items-start space-x-3">
                    <div class="w-6 h-6 bg-primary-red rounded-full flex items-center justify-center mt-1">
                        <span class="text-white text-xs font-bold">4</span>
                    </div>
                    <div>
                        <p class="font-medium text-text-black">Duplicate Handling</p>
                        <p class="text-sm text-gray-600">Employees with existing codes will be skipped</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script>
    let selectedFile = null;

    // File input change handler
    document.getElementById('fileInput').addEventListener('change', function(e) {
        if (this.files.length > 0) {
            selectedFile = this.files[0];
            displayFileInfo(selectedFile);
            document.getElementById('importBtn').disabled = false;
        }
    });

    // Drag and drop functionality
    const uploadArea = document.getElementById('uploadArea');

    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        uploadArea.addEventListener(eventName, preventDefaults, false);
    });

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    ['dragenter', 'dragover'].forEach(eventName => {
        uploadArea.addEventListener(eventName, highlight, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        uploadArea.addEventListener(eventName, unhighlight, false);
    });

    function highlight() {
        uploadArea.classList.add('border-secondary-blue', 'bg-blue-50');
    }

    function unhighlight() {
        uploadArea.classList.remove('border-secondary-blue', 'bg-blue-50');
    }

    uploadArea.addEventListener('drop', handleDrop, false);

    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;

        if (files.length > 0) {
            selectedFile = files[0];
            displayFileInfo(selectedFile);
            document.getElementById('importBtn').disabled = false;
        }
    }

    function displayFileInfo(file) {
        document.getElementById('fileName').textContent = file.name;
        document.getElementById('fileSize').textContent = formatFileSize(file.size);
        document.getElementById('fileInfo').classList.remove('hidden');
    }

    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    function removeFile() {
        selectedFile = null;
        document.getElementById('fileInput').value = '';
        document.getElementById('fileInfo').classList.add('hidden');
        document.getElementById('importBtn').disabled = true;
    }

    function processImport() {
        if (!selectedFile) return;

        const formData = new FormData();
        formData.append('file', selectedFile);

        // Show loading state
        const importBtn = document.getElementById('importBtn');
        importBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i><span>Importing...</span>';
        importBtn.disabled = true;

        fetch('{{ route("admin.employees.process-import") }}', {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': '{{ csrf_token() }}'
            },
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('success', data.success);
                setTimeout(() => {
                    window.location.href = '{{ route("admin.employees.index") }}';
                }, 2000);
            } else if (data.error) {
                showNotification('error', data.error);
                importBtn.innerHTML = '<i class="fas fa-upload"></i><span>Import Employees</span>';
                importBtn.disabled = false;
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showNotification('error', 'An error occurred during import.');
            importBtn.innerHTML = '<i class="fas fa-upload"></i><span>Import Employees</span>';
            importBtn.disabled = false;
        });
    }

    function downloadTemplate() {
        // Create a simple template download
        const headers = [
            'employee_code', 'payroll_no', 'employment_type', 'title', 'first_name',
            'middle_name', 'last_name', 'icard_number', 'department', 'sub_department',
            'designation', 'category', 'gender'
        ];

        const exampleData = [
            'EMP000464', '2000', 'Regular', 'Mr.', 'John', '', 'Doe', '0036031986',
            'Infrastructure & External Development', '', 'Mason', 'New ham', 'Male'
        ];

        let csvContent = headers.join(',') + '\n' + exampleData.join(',');

        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.setAttribute('hidden', '');
        a.setAttribute('href', url);
        a.setAttribute('download', 'employee_import_template.csv');
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    }

    function showNotification(type, message) {
        const notification = document.createElement('div');
        notification.className = `fixed top-4 right-4 p-4 rounded-lg shadow-lg z-50 ${
            type === 'success' ? 'bg-green-500 text-white' : 'bg-red-500 text-white'
        }`;
        notification.innerHTML = `
            <div class="flex items-center space-x-2">
                <i class="fas fa-${type === 'success' ? 'check' : 'exclamation-triangle'}"></i>
                <span>${message}</span>
            </div>
        `;

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.remove();
        }, 5000);
    }
</script>
@endsection
