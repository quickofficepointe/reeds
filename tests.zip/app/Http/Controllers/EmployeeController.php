<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use App\Models\Department;
use App\Models\SubDepartment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $employees = Employee::with(['department', 'subDepartment'])
            ->latest()
            ->paginate(20);

        $departments = Department::active()->get(); // For modal dropdowns
        $subDepartments = SubDepartment::active()->get(); // For modal dropdowns

        return view('reeds.admin.employees.index', compact('employees', 'departments', 'subDepartments'));
    }

     public function import()
    {
        return view('reeds.admin.employees.import');
    }

    /**
     * Process employee import
     */
    public function processImport(Request $request)
    {
        $request->validate([
            'file' => 'required|file|mimes:xlsx,xls,csv|max:10240'
        ]);

        try {
            Excel::import(new EmployeesImport, $request->file('file'));

            return response()->json([
                'success' => 'Employees imported successfully!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Failed to import employees: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Export employees
     */
    public function export()
    {
        return Excel::download(new EmployeesExport, 'employees_' . date('Y-m-d') . '.xlsx');
    }

    /**
     * Show QR codes page
     */
    public function qrCodes()
    {
        $employees = Employee::with(['department', 'subDepartment'])
            ->whereNotNull('qr_code')
            ->latest()
            ->paginate(20);

        return view('reeds.admin.employees.qr-codes', compact('employees'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'employee_code' => 'required|string|max:50|unique:employees',
            'department_id' => 'required|exists:departments,id',
            'sub_department_id' => 'nullable|exists:sub_departments,id',
            'payroll_no' => 'nullable|string|max:50|unique:employees',
            'employment_type' => 'required|string|max:50',
            'title' => 'nullable|string|max:20',
            'first_name' => 'required|string|max:100',
            'middle_name' => 'nullable|string|max:100',
            'last_name' => 'required|string|max:100',
            'icard_number' => 'nullable|string|max:50|unique:employees',
            'gender' => 'nullable|in:Male,Female,Other',
            'designation' => 'nullable|string|max:100',
            'category' => 'nullable|string|max:100',
        ]);

        try {
            DB::transaction(function () use ($request) {
                $employee = Employee::create($request->all());
                $employee->generateQrCode();
            });

            return response()->json(['success' => 'Employee created successfully! QR code generated.']);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Failed to create employee: ' . $e->getMessage()], 500);
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Employee $employee)
    {
        $request->validate([
            'employee_code' => 'required|string|max:50|unique:employees,employee_code,' . $employee->id,
            'department_id' => 'required|exists:departments,id',
            'sub_department_id' => 'nullable|exists:sub_departments,id',
            'payroll_no' => 'nullable|string|max:50|unique:employees,payroll_no,' . $employee->id,
            'employment_type' => 'required|string|max:50',
            'title' => 'nullable|string|max:20',
            'first_name' => 'required|string|max:100',
            'middle_name' => 'nullable|string|max:100',
            'last_name' => 'required|string|max:100',
            'icard_number' => 'nullable|string|max:50|unique:employees,icard_number,' . $employee->id,
            'gender' => 'nullable|in:Male,Female,Other',
            'designation' => 'nullable|string|max:100',
            'category' => 'nullable|string|max:100',
            'is_active' => 'boolean',
        ]);

        try {
            $employee->update($request->all());
            return response()->json(['success' => 'Employee updated successfully!']);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Failed to update employee: ' . $e->getMessage()], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Employee $employee)
    {
        try {
            $employee->delete();
            return response()->json(['success' => 'Employee deleted successfully!']);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Failed to delete employee: ' . $e->getMessage()], 500);
        }
    }

    /**
     * Generate QR code for employee
     */
    public function generateQrCode(Employee $employee)
    {
        try {
            $qrCode = $employee->generateQrCode();
            return response()->json([
                'success' => 'QR code generated successfully!',
                'qr_code' => $qrCode
            ]);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Failed to generate QR code!'], 500);
        }
    }

    /**
     * Toggle employee status
     */
    public function toggleStatus(Employee $employee)
    {
        try {
            $employee->update([
                'is_active' => !$employee->is_active
            ]);

            $status = $employee->is_active ? 'activated' : 'deactivated';
            return response()->json(['success' => "Employee {$status} successfully!"]);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Failed to update employee status!'], 500);
        }
    }

    /**
     * Get employees by department (for filtering)
     */
    public function byDepartment(Department $department)
    {
        try {
            $employees = $department->employees()->with('subDepartment')->active()->get();
            return response()->json($employees);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Failed to fetch employees!'], 500);
        }
    }

    /**
     * Get employees by sub-department (for filtering)
     */
    public function bySubDepartment(SubDepartment $subDepartment)
    {
        try {
            $employees = $subDepartment->employees()->active()->get();
            return response()->json($employees);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Failed to fetch employees!'], 500);
        }
    }
}
