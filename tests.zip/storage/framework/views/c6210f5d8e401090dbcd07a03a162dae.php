<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto">
    <!-- Header -->
    <div class="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
            <h1 class="text-3xl font-bold text-text-black">Employee QR Codes</h1>
            <p class="text-gray-600 mt-2">View and manage employee QR codes for scanning</p>
        </div>
        <div class="flex space-x-3 mt-4 md:mt-0">
            <a href="<?php echo e(route('admin.employees.index')); ?>" class="bg-gray-500 text-white px-6 py-3 rounded-lg font-semibold hover:bg-gray-600 transition duration-300 shadow-md flex items-center space-x-2">
                <i class="fas fa-arrow-left"></i>
                <span>Back to Employees</span>
            </a>
        </div>
    </div>

    <!-- Stats -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div class="bg-white rounded-xl shadow-md border border-gray-100 p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Total QR Codes</p>
                    <p class="text-2xl font-bold text-text-black mt-2"><?php echo e($employees->total()); ?></p>
                </div>
                <div class="w-12 h-12 bg-secondary-blue bg-opacity-10 rounded-full flex items-center justify-center">
                    <i class="fas fa-qrcode text-secondary-blue text-xl"></i>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-md border border-gray-100 p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Active Employees</p>
                    <p class="text-2xl font-bold text-text-black mt-2"><?php echo e($employees->where('is_active', true)->count()); ?></p>
                </div>
                <div class="w-12 h-12 bg-green-500 bg-opacity-10 rounded-full flex items-center justify-center">
                    <i class="fas fa-check-circle text-green-500 text-xl"></i>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-md border border-gray-100 p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Ready for Printing</p>
                    <p class="text-2xl font-bold text-text-black mt-2"><?php echo e($employees->count()); ?></p>
                </div>
                <div class="w-12 h-12 bg-primary-red bg-opacity-10 rounded-full flex items-center justify-center">
                    <i class="fas fa-print text-primary-red text-xl"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- QR Codes Grid -->
    <div class="bg-white rounded-xl shadow-md border border-gray-100 p-6">
        <div class="flex items-center justify-between mb-6">
            <h2 class="text-xl font-bold text-text-black">Generated QR Codes</h2>
            <div class="flex space-x-3">
                <button onclick="downloadAllMealCards()" class="bg-secondary-blue text-white px-4 py-2 rounded-lg font-semibold hover:bg-blue-600 transition duration-300 flex items-center space-x-2">
                    <i class="fas fa-download"></i>
                    <span>Download All</span>
                </button>
                <button onclick="printQRCodes()" class="bg-primary-red text-white px-4 py-2 rounded-lg font-semibold hover:bg-[#c22120] transition duration-300 flex items-center space-x-2">
                    <i class="fas fa-print"></i>
                    <span>Print All</span>
                </button>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6" id="qrCodesGrid">
            <?php $__empty_1 = true; $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="border border-gray-200 rounded-lg p-4 text-center hover:shadow-md transition duration-150">
                <!-- QR Code -->
                <div class="bg-gray-100 rounded-lg p-4 mb-3 flex items-center justify-center h-32">
                    <div class="text-center">
                        <div id="qrcode-<?php echo e($employee->id); ?>" class="qrcode-container"></div>
                    </div>
                </div>

                <div class="space-y-2">
                    <h3 class="font-semibold text-text-black text-sm"><?php echo e($employee->formal_name); ?></h3>
                    <p class="text-xs text-gray-500"><?php echo e($employee->employee_code); ?></p>
                    <p class="text-xs text-gray-600"><?php echo e($employee->department->name); ?></p>

                    <div class="flex justify-center space-x-2 mt-3">
                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium <?php echo e($employee->is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'); ?>">
                            <?php echo e($employee->is_active ? 'Active' : 'Inactive'); ?>

                        </span>
                    </div>
                </div>

                <div class="mt-4">
                    <button onclick="downloadMealCard(<?php echo e($employee->id); ?>)" class="bg-secondary-blue text-white px-3 py-1 rounded text-xs font-medium hover:bg-blue-600 transition duration-300 flex items-center space-x-1 mx-auto">
                        <i class="fas fa-download text-xs"></i>
                        <span>Download Card</span>
                    </button>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-full text-center py-12">
                <i class="fas fa-qrcode text-4xl text-gray-300 mb-3"></i>
                <p class="text-lg text-gray-500">No QR codes generated yet</p>
                <p class="text-sm text-gray-400 mt-1">Generate QR codes for employees first</p>
                <a href="<?php echo e(route('admin.employees.index')); ?>" class="inline-block mt-4 bg-primary-red text-white px-6 py-2 rounded-lg font-semibold hover:bg-[#c22120] transition duration-300">
                    Go to Employees
                </a>
            </div>
            <?php endif; ?>
        </div>

        <!-- Pagination -->
        <?php if($employees->hasPages()): ?>
        <div class="mt-6 border-t border-gray-200 pt-4">
            <?php echo e($employees->links()); ?>

        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Hidden Meal Card Template -->
<div id="mealCardTemplate" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 hidden">
    <div class="bg-white p-6 rounded-lg max-w-4xl max-h-screen overflow-y-auto">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-xl font-bold text-text-black">Meal Card Preview</h3>
            <button onclick="closeMealCardPreview()" class="text-gray-500 hover:text-gray-700">
                <i class="fas fa-times text-xl"></i>
            </button>
        </div>

        <div id="mealCardContainer" class="bg-card-bg shadow-2xl overflow-hidden"
             style="width: 600px; height: 1050px;">

            <div class="p-12 flex flex-col items-center">

                <div class="mb-8">
                    <img src="<?php echo e(asset('Assets/images/Reeds_Logo.png')); ?>" alt="Reeds Africa Consult Logo" class="h-24 mx-auto object-contain">
                </div>

                <h1 class="text-3xl font-bold tracking-wider text-black mt-8 mb-12">
                    OFFICIAL MEAL CARD
                </h1>

                <div class="w-[450px] h-[450px] border-[15px] border-amber-900 bg-white p-4 flex items-center justify-center">
                    <div class="w-full h-full flex items-center justify-center text-center">
                        <div id="previewQrCode"></div>
                    </div>
                </div>
            </div>

            <!-- EMPLOYEE DETAILS -->
            <div class="bg-primary-red text-white p-12 mt-auto h-48 flex flex-col justify-center">
                <p class="text-xl font-light mb-2">
                    <span class="font-normal">Employee No:</span>
                    <span id="previewEmpNo" class="ml-2 font-light italic"></span>
                </p>
                <p class="text-xl font-light mb-2">
                    <span class="font-normal">Name:</span>
                    <span id="previewEmpName" class="ml-2 font-light italic"></span>
                </p>
                <p class="text-xl font-light">
                    <span class="font-normal">Designation:</span>
                    <span id="previewEmpPos" class="ml-2 font-light italic"></span>
                </p>
            </div>

            <div class="flex justify-between items-center px-12 py-4 bg-white border-t border-gray-200">
                <p class="text-xs text-gray-500">
                    Powered By: <span class="font-semibold text-secondary-blue">www.biztrak.ke</span>
                </p>
                <div class="w-16 h-8 bg-secondary-blue text-white flex items-center justify-center text-xs font-bold rounded">
                    BizTrak
                </div>
            </div>
        </div>

        <div class="mt-4 flex justify-center">
            <button id="downloadPreviewCardBtn" class="bg-secondary-blue text-white px-6 py-3 rounded-lg shadow-lg hover:bg-primary-red transition font-semibold">
                Download Meal Card
            </button>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- QRCode.js CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<!-- html2canvas CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>

<script>
    // Employee data from backend
    const employees = <?php echo json_encode($employees->items()); ?>;

    // Generate QR codes for each employee
    document.addEventListener('DOMContentLoaded', function() {
        employees.forEach(employee => {
            const qrContainer = document.getElementById(`qrcode-${employee.id}`);
            if (qrContainer) {
                // Clear container
                qrContainer.innerHTML = '';

                // Get current date and time
                const now = new Date();
                const formattedDate = now.toLocaleString('en-KE', {
                    dateStyle: 'full',
                    timeStyle: 'short'
                });

                // Build QR code data
                const qrData = `
Reeds Africa Consult - Official Meal Card
Employee No: ${employee.employee_code}
Name: ${employee.formal_name}
Department: ${employee.department.name}
Printed: ${formattedDate}
                `.trim();

                // Generate QR code
                new QRCode(qrContainer, {
                    text: qrData,
                    width: 100,
                    height: 100,
                    colorDark: "#000000",
                    colorLight: "#ffffff",
                    correctLevel: QRCode.CorrectLevel.H
                });
            }
        });
    });

    // Function to download individual meal card
    function downloadMealCard(employeeId) {
        const employee = employees.find(emp => emp.id === employeeId);
        if (!employee) return;

        // Get current date and time
        const now = new Date();
        const formattedDate = now.toLocaleString('en-KE', {
            dateStyle: 'full',
            timeStyle: 'short'
        });

        // Build QR code data
        const qrData = `
Reeds Africa Consult - Official Meal Card
Employee No: ${employee.employee_code}
Name: ${employee.formal_name}
Department: ${employee.department.name}
Printed: ${formattedDate}
        `.trim();

        // Update preview modal
        document.getElementById('previewEmpNo').textContent = employee.employee_code;
        document.getElementById('previewEmpName').textContent = employee.formal_name;
        document.getElementById('previewEmpPos').textContent = employee.department.name;

        // Generate QR code for preview
        const previewContainer = document.getElementById('previewQrCode');
        previewContainer.innerHTML = '';
        new QRCode(previewContainer, {
            text: qrData,
            width: 400,
            height: 400,
            colorDark: "#000000",
            colorLight: "#ffffff",
            correctLevel: QRCode.CorrectLevel.H
        });

        // Set up download button for this specific employee
        document.getElementById('downloadPreviewCardBtn').onclick = function() {
            downloadEmployeeCard(employee, qrData);
        };

        // Show preview modal
        document.getElementById('mealCardTemplate').classList.remove('hidden');
    }

    // Function to download all meal cards as a ZIP
    async function downloadAllMealCards() {
        // Show loading state
        const downloadBtn = document.querySelector('button[onclick="downloadAllMealCards()"]');
        const originalText = downloadBtn.innerHTML;
        downloadBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i><span>Preparing Download...</span>';
        downloadBtn.disabled = true;

        try {
            // For each employee, generate and download their card
            for (let i = 0; i < employees.length; i++) {
                const employee = employees[i];

                // Get current date and time
                const now = new Date();
                const formattedDate = now.toLocaleString('en-KE', {
                    dateStyle: 'full',
                    timeStyle: 'short'
                });

                // Build QR code data
                const qrData = `
Reeds Africa Consult - Official Meal Card
Employee No: ${employee.employee_code}
Name: ${employee.formal_name}
Department: ${employee.department.name}
Printed: ${formattedDate}
                `.trim();

                // Create a temporary meal card for this employee
                const tempCard = document.createElement('div');
                tempCard.className = 'meal-card bg-card-bg shadow-2xl overflow-hidden';
                tempCard.style.width = '600px';
                tempCard.style.height = '1050px';

                tempCard.innerHTML = `
                    <div class="p-12 flex flex-col items-center">
                        <div class="mb-8">
                            <img src="<?php echo e(asset('Assets/images/Reeds_Logo.png')); ?>" alt="Reeds Africa Consult Logo" class="h-24 mx-auto object-contain">
                        </div>

                        <h1 class="text-3xl font-bold tracking-wider text-black mt-8 mb-12">
                            OFFICIAL MEAL CARD
                        </h1>

                        <div class="w-[450px] h-[450px] border-[15px] border-amber-900 bg-white p-4 flex items-center justify-center">
                            <div class="w-full h-full flex items-center justify-center text-center">
                                <div id="tempQrCode-${employee.id}"></div>
                            </div>
                        </div>
                    </div>

                    <div class="bg-primary-red text-white p-12 mt-auto h-48 flex flex-col justify-center">
                        <p class="text-xl font-light mb-2">
                            <span class="font-normal">Employee No:</span>
                            <span class="ml-2 font-light italic">${employee.employee_code}</span>
                        </p>
                        <p class="text-xl font-light mb-2">
                            <span class="font-normal">Name:</span>
                            <span class="ml-2 font-light italic">${employee.formal_name}</span>
                        </p>
                        <p class="text-xl font-light">
                            <span class="font-normal">Designation:</span>
                            <span class="ml-2 font-light italic">${employee.department.name}</span>
                        </p>
                    </div>

                    <div class="flex justify-between items-center px-12 py-4 bg-white border-t border-gray-200">
                        <p class="text-xs text-gray-500">
                            Powered By: <span class="font-semibold text-secondary-blue">www.biztrak.ke</span>
                        </p>
                        <div class="w-16 h-8 bg-secondary-blue text-white flex items-center justify-center text-xs font-bold rounded">
                            BizTrak
                        </div>
                    </div>
                `;

                document.body.appendChild(tempCard);

                // Generate QR code
                const qrContainer = document.getElementById(`tempQrCode-${employee.id}`);
                new QRCode(qrContainer, {
                    text: qrData,
                    width: 400,
                    height: 400,
                    colorDark: "#000000",
                    colorLight: "#ffffff",
                    correctLevel: QRCode.CorrectLevel.H
                });

                // Wait a moment for QR code to render
                await new Promise(resolve => setTimeout(resolve, 500));

                // Convert to image and download
                const canvas = await html2canvas(tempCard, { scale: 2 });
                const link = document.createElement('a');
                link.download = `MealCard_${employee.formal_name.replace(/\s+/g, '_')}.png`;
                link.href = canvas.toDataURL('image/png');
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);

                // Remove temporary card
                document.body.removeChild(tempCard);

                // Add a small delay between downloads to prevent browser issues
                if (i < employees.length - 1) {
                    await new Promise(resolve => setTimeout(resolve, 500));
                }
            }

            // Show completion message
            alert(`Successfully downloaded ${employees.length} meal cards!`);

        } catch (error) {
            console.error('Error downloading meal cards:', error);
            alert('An error occurred while downloading the meal cards. Please try again.');
        } finally {
            // Restore button state
            downloadBtn.innerHTML = originalText;
            downloadBtn.disabled = false;
        }
    }

    // Function to download a specific employee's card
    async function downloadEmployeeCard(employee, qrData) {
        try {
            // Create a temporary meal card
            const tempCard = document.createElement('div');
            tempCard.className = 'meal-card bg-card-bg shadow-2xl overflow-hidden';
            tempCard.style.width = '600px';
            tempCard.style.height = '1050px';

            tempCard.innerHTML = `
                <div class="p-12 flex flex-col items-center">
                    <div class="mb-8">
                        <img src="<?php echo e(asset('Assets/images/Reeds_Logo.png')); ?>" alt="Reeds Africa Consult Logo" class="h-24 mx-auto object-contain">
                    </div>

                    <h1 class="text-3xl font-bold tracking-wider text-black mt-8 mb-12">
                        OFFICIAL MEAL CARD
                    </h1>

                    <div class="w-[450px] h-[450px] border-[15px] border-amber-900 bg-white p-4 flex items-center justify-center">
                        <div class="w-full h-full flex items-center justify-center text-center">
                            <div id="tempQrCode"></div>
                        </div>
                    </div>
                </div>

                <div class="bg-primary-red text-white p-12 mt-auto h-48 flex flex-col justify-center">
                    <p class="text-xl font-light mb-2">
                        <span class="font-normal">Employee No:</span>
                        <span class="ml-2 font-light italic">${employee.employee_code}</span>
                    </p>
                    <p class="text-xl font-light mb-2">
                        <span class="font-normal">Name:</span>
                        <span class="ml-2 font-light italic">${employee.formal_name}</span>
                    </p>
                    <p class="text-xl font-light">
                        <span class="font-normal">Designation:</span>
                        <span class="ml-2 font-light italic">${employee.department.name}</span>
                    </p>
                </div>

                <div class="flex justify-between items-center px-12 py-4 bg-white border-t border-gray-200">
                    <p class="text-xs text-gray-500">
                        Powered By: <span class="font-semibold text-secondary-blue">www.biztrak.ke</span>
                    </p>
                    <div class="w-16 h-8 bg-secondary-blue text-white flex items-center justify-center text-xs font-bold rounded">
                        BizTrak
                    </div>
                </div>
            `;

            document.body.appendChild(tempCard);

            // Generate QR code
            const qrContainer = document.getElementById('tempQrCode');
            new QRCode(qrContainer, {
                text: qrData,
                width: 400,
                height: 400,
                colorDark: "#000000",
                colorLight: "#ffffff",
                correctLevel: QRCode.CorrectLevel.H
            });

            // Wait a moment for QR code to render
            await new Promise(resolve => setTimeout(resolve, 500));

            // Convert to image and download
            const canvas = await html2canvas(tempCard, { scale: 2 });
            const link = document.createElement('a');
            link.download = `MealCard_${employee.formal_name.replace(/\s+/g, '_')}.png`;
            link.href = canvas.toDataURL('image/png');
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);

            // Remove temporary card
            document.body.removeChild(tempCard);

            // Close the preview modal
            closeMealCardPreview();

        } catch (error) {
            console.error('Error downloading meal card:', error);
            alert('An error occurred while downloading the meal card. Please try again.');
        }
    }

    // Function to close the meal card preview
    function closeMealCardPreview() {
        document.getElementById('mealCardTemplate').classList.add('hidden');
    }

    // Function to print all QR codes (existing functionality)
    function printQRCodes() {
        // You can implement QR code printing functionality here
        // This could open a print-friendly page or generate PDF
        alert('Print functionality would be implemented here. This could generate a PDF or open a print dialog.');
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('reeds.admin.layout.adminlayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laraprojects\reeds\resources\views\reeds\admin\employees\qr-codes.blade.php ENDPATH**/ ?>